volatile int sink;

void start(void) {
    int buf[16];
    int *p = &buf[8];
    int i;

    for (i = 0; i < 16; i++) {
        buf[i] = 0;
    }

    /* Underwrite: for i < 8, we write before buf[0]. */
    for (i = 0; i < 16; i++) {
        p[i - 8] = i;   /* buf[-8]..buf[7] on first half of loop */
    }

    sink = buf[8];
}

